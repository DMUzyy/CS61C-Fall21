# numc

### Provide answers to the following questions for each set of partners.
- How many hours did you spend on the following tasks?
  - Task 1 (Matrix functions in C): ???
  - Task 2 (Writing the Python-C interface): ???
  - Task 3 (Speeding up matrix operations): ???
- Was this project interesting? What was the most interesting aspect about it?
  - <b>???</b>
- What did you learn?
  - <b>???</b>
- Is there anything you would change?
  - <b>???</b>

### If you worked with a partner:
- In one short paragraph, describe your contribution(s) to the project.
  - <b>???</b>
- In one short paragraph, describe your partner's contribution(s) to the project.
  - <b>???</b>
